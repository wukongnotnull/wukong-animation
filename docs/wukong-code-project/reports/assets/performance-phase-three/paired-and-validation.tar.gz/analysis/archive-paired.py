from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('/tmp/wka-phase3-root').read_text().strip();root=Path(root)
reports=Path('/Users/wukong/Documents/wukong-animation/docs/wukong-code-project/reports')
status=json.loads((root/'validation/final-v1/status.json').read_text())
assert status['status']=='passed',status
paths=[root/'hash-paired/results.json',root/'workflow-paired/results.json']
summary=json.loads(subprocess.check_output(['python3','/tmp/wka-phase3-summarize-pair.py',*map(str,paths)],text=True))
assert not summary['regressions'],summary['regressions']
archive=reports/'assets/performance-phase-three/paired-and-validation.tar.gz'
assert not archive.exists(),'preserve existing evidence; use a new archive for a new attempt'
with tarfile.open(archive,'w:gz') as tar:
    for folder in ['hash-paired','workflow-paired']:
        for file in sorted((root/folder).iterdir()):
            if file.is_file() and file.suffix in ['.json','.log']:tar.add(file,arcname=f'{folder}/{file.name}')
        for file in sorted((root/folder/'tool-source').rglob('*')):
            if file.is_file():tar.add(file,arcname=f'{folder}/tool-source/{file.relative_to(root/folder/"tool-source")}')
    for file in sorted((root/'validation').rglob('*')):
        if file.is_file() and file.suffix in ['.json','.log']:tar.add(file,arcname=f'validation/{file.relative_to(root/"validation")}')
    for name in ['SHASUMS256.txt','verified-sha256.txt']:
        tar.add(root/'node20'/name,arcname=f'node20/{name}')
    tar.add(root/'run-final-validation.mjs',arcname='validation/run-final-validation.mjs')
    tar.add('/tmp/wka-phase3-summarize-pair.py',arcname='analysis/summarize-pair.py')
    tar.add('/tmp/wka-phase3-archive-paired.py',arcname='analysis/archive-paired.py')
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
record={'status':'All local paired measurements and required validation commands passed; remote CI pending later PR','baseline':'5957b73e90f014011fb27d3e015d4987c39db6ba','candidate':status['candidate'],'archive':str(archive.relative_to(reports)),'archiveSha256':sha,'validation':status,'paired':summary,'environments':{file.parent.name:json.loads(file.read_text())['environment'] for file in paths}}
(reports/'2026-10-31-performance-phase-three-validation.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha,'scenarios':len(summary['scenarios']),'changedWorkCounts':summary['changedWorkCounts']},ensure_ascii=False))
