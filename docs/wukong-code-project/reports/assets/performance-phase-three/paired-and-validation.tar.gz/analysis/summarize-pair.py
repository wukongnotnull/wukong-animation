from pathlib import Path
import json,statistics,sys

def med(rows,key):return statistics.median(key(r) for r in rows)
records=[]
for name in sys.argv[1:]:
    data=json.loads(Path(name).read_text())
    if not data.get('complete'):raise SystemExit('Incomplete benchmark: '+name)
    if any(not row['ok'] for row in data['rows']):raise SystemExit('Failed sample retained in '+name)
    for scenario in data['environment']['scenarios']:
        engines={}
        for label in ['baseline','candidate']:
            rows=[r for r in data['rows'] if r['engineLabel']==label and r['scenario']==scenario]
            plain=[r for r in rows if not r['instrumented']];probes=[r for r in rows if r['instrumented']]
            expected=data['environment']['options']['rounds']
            assert sorted(r['round'] for r in plain)==list(range(1,expected+1))
            assert len(probes)==1
            summary=data['summaries'][f'{label}/{scenario}'];assert summary['ok']
            timing=med(plain,lambda r:r['wallMs']);assert abs(timing-summary['medianMs'])<1e-6
            probe=probes[0]
            audio=[v for f,v in probe['metrics']['files'].items() if f.endswith('/audio/track.wav')]
            assert len(audio)==1,(scenario,label,len(audio))
            processes=probe['metrics']['processes']
            engines[label]={'medianMs':timing,'minMs':min(r['wallMs'] for r in plain),'maxMs':max(r['wallMs'] for r in plain),'cpuMedianMs':med(plain,lambda r:(r['metrics']['cpu']['user']+r['metrics']['cpu']['system'])/1000),'maxRSSMedianMiB':med(plain,lambda r:r['metrics']['maxRSSKiB']/1024),'audioProbe':audio[0],'fsCalls':probe['metrics'].get('fsCalls',{}),'fullFrameProbes':sum('-show_frames' in p['args'] for p in processes),'ffmpegProcesses':sum(p['kind']=='ffmpeg' for p in processes),'validations':[r['validation'] for r in plain]}
        a,b=engines['baseline'],engines['candidate'];limit=max(100,a['medianMs']*.1);delta=b['medianMs']-a['medianMs']
        records.append({'suite':data['environment']['options']['suite'],'scenario':scenario,'samplesPerEngine':expected,'baseline':a,'candidate':b,'deltaMs':delta,'deltaPercent':delta/a['medianMs']*100,'regressionLimitMs':limit,'regression':delta>limit,'rangesOverlap':max(a['minMs'],b['minMs'])<=min(a['maxMs'],b['maxMs']),'workCountsEqual':a['fullFrameProbes']==b['fullFrameProbes'] and a['ffmpegProcesses']==b['ffmpegProcesses']})
print(json.dumps({'inputs':sys.argv[1:],'scenarios':records,'regressions':[r['scenario'] for r in records if r['regression']],'changedWorkCounts':[r['scenario'] for r in records if not r['workCountsEqual']]},ensure_ascii=False,indent=2))
