import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const state=JSON.parse(fs.readFileSync('/tmp/wka-phase4-state.json'));
const {root,candidate}=state;
const {runCommand,summarize}=await import(pathToFileURL(path.join(candidate,'tools/bench-performance.mjs')));
const {restoreFixture}=await import(pathToFileURL(path.join(candidate,'tests/fixtures/performance.mjs')));
const out=path.join(root,'workload-diagnostic');fs.mkdirSync(out);
const json=(p,x)=>fs.writeFileSync(p,JSON.stringify(x,null,2)+'\n');
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const rows=[];
const cases=['baseline','candidate'].map(label=>{
 const base=path.join(root,'paired-workflow',label),live=path.join(base,'remotion-example');
 const backup=path.join(base,'remotion-example-after-primary');fs.renameSync(live,backup);
 return {label,base,live,backup,warm:path.join(base,'remotion-example-preview-warm'),engine:path.join(state[label],'plugin/engine')};
});
const outputPaths=dir=>['s01','s02','s03','s04'].map(id=>path.join(dir,'review/局部小样',id+'.mp4'));
function probe(file){const p=spawnSync('ffprobe',['-v','error','-count_frames','-show_entries','stream=codec_type,width,height,r_frame_rate,nb_read_frames','-of','json',file],{encoding:'utf8'});assert.equal(p.status,0);return JSON.parse(p.stdout).streams;}
const expected=cases.map(c=>outputPaths(c.warm).map(probe));assert.deepEqual(expected[0],expected[1]);
const settings={baseline:state.baselineSha,candidate:state.candidateSha,rounds:5,instrumentedProbesPerEngine:1,description:'Supplement to original comment-only scene; replace title text with identical visible change in both isolated copies. Keep original 210 timings and 42 probes intact.',mutation:{from:'每一帧都由',to:'优化后仍逐帧'},expected,rows,complete:false};
fs.copyFileSync(new URL(import.meta.url),path.join(out,'diagnostic-source.mjs'));
json(path.join(out,'results.json'),settings);
try {
 for(let round=1;round<=6;round++) for(const ctx of round%2?cases:[...cases].reverse()) {
  restoreFixture(ctx.warm,ctx.live,'unchanged');
  const film=JSON.parse(fs.readFileSync(path.join(ctx.live,'film.json'))),shot=path.join(ctx.live,film.shots[0].file),original=fs.readFileSync(shot,'utf8');
  assert.ok(original.includes(settings.mutation.from));fs.writeFileSync(shot,original.replaceAll(settings.mutation.from,settings.mutation.to));
  const instrumented=round===6,name=ctx.label+'-'+(instrumented?'probe':round),log=path.join(out,name+'.log'),metricFile=path.join(out,name+'.metrics.json');
  const env={...process.env,WUKONG_ANIMATION_HOME:path.join(ctx.base,'home'),WKA_JIANYING_DRAFTS:path.join(ctx.base,'drafts'),WKA_NO_FONT_DOWNLOAD:'1',PLAYWRIGHT_SKIP_BROWSER_GC:'1',npm_config_cache:path.join(ctx.base,'npm-cache'),WKA_BENCH_PROBE:instrumented?'1':'0',WKA_BENCH_METRICS:metricFile};
  const args=['--import',path.join(candidate,'tools/bench-metrics.mjs'),path.join(ctx.engine,'bin/wka.mjs'),'preview',ctx.live];
  const row={...await runCommand(process.execPath,args,{env,log}),label:ctx.label,round,instrumented,inputSha256:sha(shot)};
  assert.ok(row.ok,log);const text=fs.readFileSync(log,'utf8');
  const rendered=[...text.matchAll(/渲染 (\d+) 个镜头/g)].reduce((n,m)=>n+Number(m[1]),0);assert.equal(rendered,1);assert.ok(text.includes('preview:s01] 开始'));assert.ok(text.includes('preview:s01] 完成'));
  for(const id of ['s02','s03','s04'])assert.ok(text.includes('preview:'+id+'] 复用完成产物'));
  const outputs=outputPaths(ctx.live);const streams=outputs.map(probe);assert.deepEqual(streams,expected[0]);
  assert.notEqual(sha(outputs[0]),sha(outputPaths(ctx.warm)[0]));
  for(let i=1;i<4;i++)assert.equal(sha(outputs[i]),sha(outputPaths(ctx.warm)[i]));
  row.validation={rerendered:rendered,remuxed:1,unchangedPreviews:3,streams,outputHashes:outputs.map(sha)};
  row.metrics=JSON.parse(fs.readFileSync(metricFile));rows.push(row);json(path.join(out,'results.json'),settings);
  console.log(ctx.label,round,instrumented?'probe':'timed',Math.round(row.wallMs),'ms PASS');
 }
 settings.complete=true;settings.summaries=Object.fromEntries(cases.map(c=>[c.label,summarize(rows.filter(x=>x.label===c.label&&!x.instrumented),5)]));
 settings.deltaMs=settings.summaries.candidate.medianMs-settings.summaries.baseline.medianMs;settings.gateMs=Math.max(100,.1*settings.summaries.baseline.medianMs);settings.gatePassed=settings.deltaMs<=settings.gateMs;
 json(path.join(out,'results.json'),settings);console.log(JSON.stringify(settings.summaries), 'gatePassed',settings.gatePassed);
} finally {for(const c of cases){fs.rmSync(c.live,{recursive:true,force:true});fs.renameSync(c.backup,c.live);}}
