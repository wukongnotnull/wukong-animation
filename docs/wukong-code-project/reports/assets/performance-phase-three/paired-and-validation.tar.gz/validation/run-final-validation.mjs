import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {runCommand} from '/Users/wukong/Documents/wukong-animation/tools/bench-performance.mjs';
const root='/var/folders/zc/71mnngz96gb6qpm2yznd3n4c0000gn/T/wka-phase3-_q_fm3wp';
const out=path.join(root,'validation/final-v1');fs.mkdirSync(out);
const state={status:'waiting-for-paired-workflow',candidate:'dffa230ae896f66f8c982fd35e8d0e6cfebc50d9',started:new Date().toISOString(),steps:[]};
const save=()=>fs.writeFileSync(path.join(out,'status.json'),JSON.stringify(state,null,2)+'\n');save();
const read=file=>JSON.parse(fs.readFileSync(file,'utf8'));
try {
  console.log('Waiting for owned paired benchmark 95169; no validation load during measurement.');
  await new Promise((resolve,reject)=>{const child=spawn('/usr/bin/caffeinate',['-i','-w','95169'],{stdio:'ignore'});child.once('error',reject);child.once('close',code=>code===0?resolve():reject(Error('benchmark wait failed')));});
  const regressions=[];
  for(const suite of ['hash','workflow']) {
    const data=read(path.join(root,`${suite}-paired/results.json`));
    if(!data.complete||data.rows.some(row=>!row.ok)||Object.values(data.summaries).some(row=>!row.ok))throw Error(`${suite} paired measurement incomplete or failed`);
    const expected=data.environment.scenarios.length*2*(data.environment.options.rounds+1);
    if(data.rows.length!==expected)throw Error(`${suite} unexpected sample count`);
    for(const scenario of data.environment.scenarios) {
      const before=data.summaries[`baseline/${scenario}`].medianMs,after=data.summaries[`candidate/${scenario}`].medianMs;
      if(after-before>Math.max(100,before*.1))regressions.push({scenario,before,after});
    }
    if(suite==='hash')for(const row of data.rows.filter(row=>row.instrumented&&row.engineLabel==='candidate')) {
      const targets=Object.entries(row.metrics.files).filter(([file])=>file.endsWith('/audio/track.wav'));
      const size=Number(row.scenario.match(/-(\d+)MiB$/)[1])*1024*1024,passes=row.scenario.startsWith('deliverySnapshot')?2:1;
      if(targets.length!==1||targets[0][1].bytes!==size*passes||targets[0][1].completeReads!==passes||targets[0][1].maxReadRequest>1024*1024)throw Error(`hard resource gate failed: ${row.scenario}`);
    }
  }
  state.regressions=regressions;
  if(regressions.length)throw Error('performance regressions require investigation before final validation');
  const unchanged=await runCommand('git',['diff','--exit-code',state.candidate,'--','plugin/engine','tests','.github/workflows/agent-installation.yml'],{log:path.join(out,'candidate-identity.log'),timeoutMs:10000});
  if(!unchanged.ok)throw Error('workspace runtime/tests no longer match frozen candidate');
  state.status='running';save();
  const steps=[['test','npm',['test']],['jianying','npm',['run','test:jianying']],['smoke','npm',['run','smoke']],['timing-long',process.execPath,['--test','--test-concurrency=1','tests/integration/timing.test.mjs']],['lint','npm',['run','lint']],['portable','npm',['run','build:portable']],['diff','git',['diff','--check']]];
  for(const [name,command,args] of steps) {
    state.current=name;save();console.log(`Starting ${name}`);
    const result=await runCommand(command,args,{log:path.join(out,`${name}.log`),timeoutMs:5400000,env:{...process.env,...(name==='timing-long'?{WKA_TIMING_LONG:'1'}:{})}});
    state.steps.push({name,...result});save();console.log(`${name}: ${result.ok?'PASS':'FAIL'} ${(result.wallMs/1000).toFixed(1)}s`);
    if(!result.ok)throw Error(`validation failed: ${name}`);
  }
  state.status='passed';state.finished=new Date().toISOString();delete state.current;save();console.log('All local final validation commands passed.');
} catch(error) {state.status='needs-investigation';state.error=String(error);save();console.error(error.stack);process.exitCode=1;}
